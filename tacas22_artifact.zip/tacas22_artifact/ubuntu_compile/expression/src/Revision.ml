let value = 
let date = ""
let time = ""
